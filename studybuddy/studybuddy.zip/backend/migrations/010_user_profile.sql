USE studybuddy;

ALTER TABLE users
  ADD COLUMN semester TINYINT UNSIGNED NULL;
